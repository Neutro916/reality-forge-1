// Shared constants for Trinity MCP Server

import { homedir } from "os";
import { join } from "path";

// Default trinity folder location
export const DEFAULT_TRINITY_PATH = join(homedir(), ".trinity");

// File and directory names
export const STATUS_FILE = "PING_STATUS.json";
export const MESSAGES_DIR = "messages";
export const LOGS_DIR = "logs";

// Character limits for responses
export const CHARACTER_LIMIT = 50000;

// Message retention (in milliseconds)
export const MESSAGE_RETENTION_DAYS = 7;
export const MESSAGE_RETENTION_MS = MESSAGE_RETENTION_DAYS * 24 * 60 * 60 * 1000;
