// Type definitions for Trinity MCP Server

export interface PingStatus {
  instance_id: string;
  timestamp: string;
  status: "online" | "offline" | "busy";
  current_task?: string;
  last_seen?: string;
}

export interface Message {
  id: string;
  from: string;
  to: string;
  timestamp: string;
  content: string;
  read: boolean;
}

export interface TrinityFolder {
  path: string;
  status_file: string;
  messages_dir: string;
}

export enum ResponseFormat {
  MARKDOWN = "markdown",
  JSON = "json"
}
