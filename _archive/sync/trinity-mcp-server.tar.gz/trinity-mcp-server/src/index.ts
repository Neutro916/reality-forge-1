#!/usr/bin/env node

// Main entry point for Trinity MCP Server

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { TrinityFileSystem } from "./services/filesystem.js";
import { registerTools } from "./tools/trinity.js";
import { DEFAULT_TRINITY_PATH } from "./constants.js";

/**
 * Initialize and start the Trinity MCP Server
 */
async function main(): Promise<void> {
  // Get trinity path from environment or use default
  const trinityPath = process.env.TRINITY_PATH || DEFAULT_TRINITY_PATH;

  // Initialize filesystem service
  const fs = new TrinityFileSystem(trinityPath);
  await fs.ensureTrinityStructure();

  // Create MCP server
  const server = new McpServer({
    name: "trinity-mcp-server",
    version: "1.0.0"
  });

  // Register all tools
  registerTools(server, fs);

  // Note: Resource registration APIs may vary by SDK version
  // If resources are needed, they can be added based on your specific SDK version

  // Connect stdio transport
  const transport = new StdioServerTransport();
  await server.connect(transport);

  // Log to stderr (stdout is reserved for MCP protocol)
  console.error("Trinity MCP Server started");
  console.error(`Trinity folder: ${trinityPath}`);
  console.error("Listening on stdio...");
}

// Handle errors
main().catch((error: unknown) => {
  console.error("Fatal error:", error);
  process.exit(1);
});
