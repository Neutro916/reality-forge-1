// Tool implementations for Trinity MCP Server

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { TrinityFileSystem } from "../services/filesystem.js";
import {
  UpdateStatusSchema,
  ReadStatusSchema,
  SendMessageSchema,
  ListMessagesSchema,
  MarkReadSchema,
  ReadFileSchema,
  ListFilesSchema
} from "../schemas/validation.js";
import { z } from "zod";

export function registerTools(server: McpServer, fs: TrinityFileSystem): void {
  
  // Tool: Update instance status
  server.registerTool(
    "trinity_update_status",
    {
      title: "Update Instance Status",
      description: `Update the status of a Claude instance in PING_STATUS.json.

Args:
  - instance_id: Unique identifier for this instance
  - status: Current status ('online' | 'offline' | 'busy')
  - current_task: Optional description of current task

Returns: Confirmation with timestamp`,
      inputSchema: UpdateStatusSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false
      }
    },
    async (params: z.infer<typeof UpdateStatusSchema>, _extra: any) => {
      try {
        await fs.updateInstanceStatus(params.instance_id, {
          status: params.status,
          current_task: params.current_task
        });

        return {
          content: [{
            type: "text",
            text: `✓ Status updated for ${params.instance_id}: ${params.status}${params.current_task ? `\nTask: ${params.current_task}` : ''}`
          }]
        };
      } catch (error: unknown) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        return {
          content: [{
            type: "text",
            text: `Error updating status: ${errorMessage}`
          }],
          isError: true
        };
      }
    }
  );

  // Tool: Read status file
  server.registerTool(
    "trinity_read_status",
    {
      title: "Read Instance Statuses",
      description: `Read PING_STATUS.json to see all Claude instance statuses.

Args:
  - instance_id: Optional filter for specific instance

Returns: List of instance statuses with timestamps`,
      inputSchema: ReadStatusSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false
      }
    },
    async (params: z.infer<typeof ReadStatusSchema>, _extra: any) => {
      try {
        let statuses = await fs.readStatus();

        if (params.instance_id) {
          statuses = statuses.filter(s => s.instance_id === params.instance_id);
        }

        if (statuses.length === 0) {
          return {
            content: [{
              type: "text",
              text: params.instance_id 
                ? `No status found for instance: ${params.instance_id}`
                : "No instances registered yet"
            }]
          };
        }

        const lines = statuses.map(s => 
          `• ${s.instance_id}: ${s.status.toUpperCase()}${s.current_task ? ` - ${s.current_task}` : ''}\n  Last seen: ${s.last_seen || s.timestamp}`
        );

        return {
          content: [{
            type: "text",
            text: `Instance Statuses (${statuses.length}):\n\n${lines.join('\n\n')}`
          }]
        };
      } catch (error: unknown) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        return {
          content: [{
            type: "text",
            text: `Error reading status: ${errorMessage}`
          }],
          isError: true
        };
      }
    }
  );

  // Tool: Send message
  server.registerTool(
    "trinity_send_message",
    {
      title: "Send Message to Instance",
      description: `Send a message to another Claude instance.

Args:
  - from: Sender instance ID
  - to: Recipient instance ID  
  - content: Message content (max 10KB)

Returns: Confirmation with message ID`,
      inputSchema: SendMessageSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: false,
        openWorldHint: false
      }
    },
    async (params: z.infer<typeof SendMessageSchema>, _extra: any) => {
      try {
        const message = await fs.sendMessage(params.from, params.to, params.content);

        return {
          content: [{
            type: "text",
            text: `✓ Message sent from ${params.from} to ${params.to}\nMessage ID: ${message.id}`
          }]
        };
      } catch (error: unknown) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        return {
          content: [{
            type: "text",
            text: `Error sending message: ${errorMessage}`
          }],
          isError: true
        };
      }
    }
  );

  // Tool: List messages
  server.registerTool(
    "trinity_list_messages",
    {
      title: "List Messages",
      description: `List messages for an instance.

Args:
  - instance_id: Optional filter for specific instance
  - unread_only: Show only unread messages
  - limit: Max messages to return (1-100, default: 20)

Returns: List of messages sorted by timestamp`,
      inputSchema: ListMessagesSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false
      }
    },
    async (params: z.infer<typeof ListMessagesSchema>, _extra: any) => {
      try {
        let messages = await fs.listMessages(params.instance_id);

        if (params.unread_only) {
          messages = messages.filter(m => !m.read);
        }

        const limit = params.limit || 20;
        messages = messages.slice(0, limit);

        if (messages.length === 0) {
          return {
            content: [{
              type: "text",
              text: params.unread_only ? "No unread messages" : "No messages found"
            }]
          };
        }

        const lines = messages.map(m => 
          `${m.read ? '✓' : '●'} [${m.id}]\nFrom: ${m.from} → To: ${m.to}\nTime: ${m.timestamp}\n${m.content}`
        );

        return {
          content: [{
            type: "text",
            text: `Messages (${messages.length}):\n\n${lines.join('\n\n---\n\n')}`
          }]
        };
      } catch (error: unknown) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        return {
          content: [{
            type: "text",
            text: `Error listing messages: ${errorMessage}`
          }],
          isError: true
        };
      }
    }
  );

  // Tool: Mark message as read
  server.registerTool(
    "trinity_mark_read",
    {
      title: "Mark Message as Read",
      description: `Mark a message as read.

Args:
  - message_id: ID of the message

Returns: Confirmation`,
      inputSchema: MarkReadSchema,
      annotations: {
        readOnlyHint: false,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false
      }
    },
    async (params: z.infer<typeof MarkReadSchema>, _extra: any) => {
      try {
        await fs.markMessageRead(params.message_id);

        return {
          content: [{
            type: "text",
            text: `✓ Message ${params.message_id} marked as read`
          }]
        };
      } catch (error: unknown) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        return {
          content: [{
            type: "text",
            text: `Error marking message as read: ${errorMessage}`
          }],
          isError: true
        };
      }
    }
  );

  // Tool: Read file from trinity folder
  server.registerTool(
    "trinity_read_file",
    {
      title: "Read Trinity File",
      description: `Read any file from the .trinity folder.

Args:
  - path: Relative path within .trinity folder

Returns: File contents

Security: Path must be within .trinity folder`,
      inputSchema: ReadFileSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false
      }
    },
    async (params: z.infer<typeof ReadFileSchema>, _extra: any) => {
      try {
        const content = await fs.readTrinityFile(params.path);

        return {
          content: [{
            type: "text",
            text: `File: ${params.path}\n\n${content}`
          }]
        };
      } catch (error: unknown) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        return {
          content: [{
            type: "text",
            text: `Error reading file: ${errorMessage}`
          }],
          isError: true
        };
      }
    }
  );

  // Tool: List files in trinity folder
  server.registerTool(
    "trinity_list_files",
    {
      title: "List Trinity Files",
      description: `List files and directories in .trinity folder.

Args:
  - path: Relative path within .trinity (empty for root)

Returns: List of files and directories

Security: Path must be within .trinity folder`,
      inputSchema: ListFilesSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: false
      }
    },
    async (params: z.infer<typeof ListFilesSchema>, _extra: any) => {
      try {
        const path = params.path || "";
        const entries = await fs.listTrinityContents(path);

        if (entries.length === 0) {
          return {
            content: [{
              type: "text",
              text: `Directory is empty: ${path || '.trinity/'}`
            }]
          };
        }

        return {
          content: [{
            type: "text",
            text: `Contents of ${path || '.trinity/'}:\n\n${entries.join('\n')}`
          }]
        };
      } catch (error: unknown) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        return {
          content: [{
            type: "text",
            text: `Error listing files: ${errorMessage}`
          }],
          isError: true
        };
      }
    }
  );
}
