// Zod validation schemas for Trinity MCP Server

import { z } from "zod";
import { ResponseFormat } from "../types.js";

export const UpdateStatusSchema = z.object({
  instance_id: z.string()
    .min(1, "Instance ID must not be empty")
    .describe("Unique identifier for this Claude instance (e.g., 'desktop', 'code-1', 'code-2')"),
  status: z.enum(["online", "offline", "busy"])
    .describe("Current status of the instance"),
  current_task: z.string()
    .optional()
    .describe("Optional description of what the instance is currently doing")
}).strict();

export const ReadStatusSchema = z.object({
  instance_id: z.string()
    .optional()
    .describe("Optional: filter to specific instance")
}).strict();

export const SendMessageSchema = z.object({
  from: z.string()
    .min(1, "From field must not be empty")
    .describe("Sender instance ID"),
  to: z.string()
    .min(1, "To field must not be empty")
    .describe("Recipient instance ID"),
  content: z.string()
    .min(1, "Message content must not be empty")
    .max(10000, "Message content must not exceed 10000 characters")
    .describe("Message content to send")
}).strict();

export const ListMessagesSchema = z.object({
  instance_id: z.string()
    .optional()
    .describe("Optional: filter messages for specific instance (sent to or from)"),
  unread_only: z.boolean()
    .optional()
    .describe("If true, only return unread messages"),
  limit: z.number()
    .int()
    .min(1)
    .max(100)
    .optional()
    .describe("Maximum number of messages to return (default: 20)")
}).strict();

export const MarkReadSchema = z.object({
  message_id: z.string()
    .min(1, "Message ID must not be empty")
    .describe("ID of the message to mark as read")
}).strict();

export const ReadFileSchema = z.object({
  path: z.string()
    .min(1, "Path must not be empty")
    .describe("Relative path within the .trinity folder (e.g., 'logs/debug.log')")
}).strict();

export const ListFilesSchema = z.object({
  path: z.string()
    .optional()
    .describe("Relative path within .trinity folder (empty for root)")
}).strict();
