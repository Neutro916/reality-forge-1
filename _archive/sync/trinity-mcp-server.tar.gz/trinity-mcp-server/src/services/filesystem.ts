// Filesystem operations for Trinity MCP Server

import { promises as fs } from "fs";
import { join, dirname } from "path";
import { PingStatus, Message } from "../types.js";
import {
  DEFAULT_TRINITY_PATH,
  STATUS_FILE,
  MESSAGES_DIR,
  MESSAGE_RETENTION_MS
} from "../constants.js";

export class TrinityFileSystem {
  private trinityPath: string;

  constructor(trinityPath?: string) {
    this.trinityPath = trinityPath || DEFAULT_TRINITY_PATH;
  }

  /**
   * Ensure the trinity directory structure exists
   */
  async ensureTrinityStructure(): Promise<void> {
    await fs.mkdir(this.trinityPath, { recursive: true });
    await fs.mkdir(join(this.trinityPath, MESSAGES_DIR), { recursive: true });
  }

  /**
   * Get the full path to the status file
   */
  getStatusPath(): string {
    return join(this.trinityPath, STATUS_FILE);
  }

  /**
   * Get the full path to the messages directory
   */
  getMessagesPath(): string {
    return join(this.trinityPath, MESSAGES_DIR);
  }

  /**
   * Read the ping status file
   */
  async readStatus(): Promise<PingStatus[]> {
    try {
      const statusPath = this.getStatusPath();
      const data = await fs.readFile(statusPath, "utf-8");
      return JSON.parse(data) as PingStatus[];
    } catch (error: unknown) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") {
        return [];
      }
      throw error;
    }
  }

  /**
   * Write the ping status file
   */
  async writeStatus(statuses: PingStatus[]): Promise<void> {
    await this.ensureTrinityStructure();
    const statusPath = this.getStatusPath();
    await fs.writeFile(statusPath, JSON.stringify(statuses, null, 2), "utf-8");
  }

  /**
   * Update status for a specific instance
   */
  async updateInstanceStatus(instanceId: string, status: Partial<PingStatus>): Promise<void> {
    const statuses = await this.readStatus();
    const index = statuses.findIndex(s => s.instance_id === instanceId);

    const timestamp = new Date().toISOString();
    const updatedStatus: PingStatus = {
      instance_id: instanceId,
      timestamp,
      status: status.status || "online",
      ...(status.current_task && { current_task: status.current_task }),
      last_seen: timestamp
    };

    if (index >= 0) {
      statuses[index] = { ...statuses[index], ...updatedStatus };
    } else {
      statuses.push(updatedStatus);
    }

    await this.writeStatus(statuses);
  }

  /**
   * List all messages for a specific instance
   */
  async listMessages(instanceId?: string): Promise<Message[]> {
    try {
      const messagesPath = this.getMessagesPath();
      const files = await fs.readdir(messagesPath);

      const messages: Message[] = [];
      for (const file of files) {
        if (!file.endsWith(".json")) continue;

        try {
          const filePath = join(messagesPath, file);
          const data = await fs.readFile(filePath, "utf-8");
          const message = JSON.parse(data) as Message;

          // Filter by instance if specified
          if (!instanceId || message.to === instanceId || message.from === instanceId) {
            messages.push(message);
          }
        } catch {
          // Skip invalid message files
          continue;
        }
      }

      // Sort by timestamp (newest first)
      messages.sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );

      return messages;
    } catch (error: unknown) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") {
        return [];
      }
      throw error;
    }
  }

  /**
   * Send a message to another instance
   */
  async sendMessage(from: string, to: string, content: string): Promise<Message> {
    await this.ensureTrinityStructure();

    const message: Message = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      from,
      to,
      timestamp: new Date().toISOString(),
      content,
      read: false
    };

    const messagesPath = this.getMessagesPath();
    const filePath = join(messagesPath, `${message.id}.json`);
    await fs.writeFile(filePath, JSON.stringify(message, null, 2), "utf-8");

    return message;
  }

  /**
   * Mark a message as read
   */
  async markMessageRead(messageId: string): Promise<void> {
    const messagesPath = this.getMessagesPath();
    const filePath = join(messagesPath, `${messageId}.json`);

    try {
      const data = await fs.readFile(filePath, "utf-8");
      const message = JSON.parse(data) as Message;
      message.read = true;
      await fs.writeFile(filePath, JSON.stringify(message, null, 2), "utf-8");
    } catch (error: unknown) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") {
        throw new Error(`Message ${messageId} not found`);
      }
      throw error;
    }
  }

  /**
   * Clean up old messages
   */
  async cleanupOldMessages(): Promise<number> {
    const messagesPath = this.getMessagesPath();
    const cutoffTime = Date.now() - MESSAGE_RETENTION_MS;
    let deletedCount = 0;

    try {
      const files = await fs.readdir(messagesPath);

      for (const file of files) {
        if (!file.endsWith(".json")) continue;

        const filePath = join(messagesPath, file);
        const data = await fs.readFile(filePath, "utf-8");
        const message = JSON.parse(data) as Message;

        if (new Date(message.timestamp).getTime() < cutoffTime) {
          await fs.unlink(filePath);
          deletedCount++;
        }
      }
    } catch (error: unknown) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") {
        throw error;
      }
    }

    return deletedCount;
  }

  /**
   * Read any file from the trinity folder
   */
  async readTrinityFile(relativePath: string): Promise<string> {
    const fullPath = join(this.trinityPath, relativePath);
    
    // Security check: ensure path is within trinity folder
    if (!fullPath.startsWith(this.trinityPath)) {
      throw new Error("Path must be within trinity folder");
    }

    return await fs.readFile(fullPath, "utf-8");
  }

  /**
   * List contents of trinity folder
   */
  async listTrinityContents(relativePath: string = ""): Promise<string[]> {
    const fullPath = join(this.trinityPath, relativePath);
    
    // Security check
    if (!fullPath.startsWith(this.trinityPath)) {
      throw new Error("Path must be within trinity folder");
    }

    const entries = await fs.readdir(fullPath, { withFileTypes: true });
    return entries.map(entry => {
      const prefix = entry.isDirectory() ? "[DIR] " : "";
      return `${prefix}${entry.name}`;
    });
  }
}
