# Trinity MCP Server

A Model Context Protocol (MCP) server for inter-Claude instance communication via a shared filesystem.

## Overview

Trinity MCP Server enables multiple Claude instances (desktop, Claude Code terminals, etc.) to communicate with each other through a shared `.trinity` folder. This allows coordinated multi-agent workflows where different Claude instances can:

- Share status updates (online/offline/busy)
- Send messages to each other
- Coordinate on tasks
- Share files and data

## Features

- **Status Management**: Update and read instance statuses via `PING_STATUS.json`
- **Message Queue**: Send and receive messages between instances
- **File Access**: Read and list files in the `.trinity` folder
- **Resources**: Expose trinity folder contents as MCP resources
- **Automatic Cleanup**: Old messages are automatically cleaned up

## Installation

### Prerequisites

- Node.js 18+ and npm
- TypeScript

### Install Dependencies

```bash
cd trinity-mcp-server
npm install
```

### Build

```bash
npm run build
```

This will compile TypeScript to JavaScript in the `dist/` directory.

## Configuration

### Claude Desktop

Add to your Claude Desktop config file:

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows**: `%APPDATA%/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "trinity": {
      "command": "node",
      "args": ["/absolute/path/to/trinity-mcp-server/dist/index.js"],
      "env": {
        "TRINITY_PATH": "/path/to/your/.trinity"
      }
    }
  }
}
```

### Claude Code

Add to your Claude Code MCP settings file:

**macOS/Linux**: `~/.config/claude/mcp_config.json`
**Windows**: `%APPDATA%/claude/mcp_config.json`

```json
{
  "mcpServers": {
    "trinity": {
      "command": "node",
      "args": ["/absolute/path/to/trinity-mcp-server/dist/index.js"],
      "env": {
        "TRINITY_PATH": "/path/to/your/.trinity"
      }
    }
  }
}
```

### Environment Variables

- `TRINITY_PATH`: Path to the trinity folder (default: `~/.trinity`)

## Trinity Folder Structure

```
.trinity/
├── PING_STATUS.json          # Instance statuses
├── messages/                 # Message queue
│   ├── <timestamp>-<id>.json
│   └── ...
└── logs/                     # Optional logs
    └── ...
```

## Available Tools

### 1. `trinity_update_status`

Update your instance's status.

**Parameters:**
- `instance_id` (string): Your instance ID (e.g., "desktop", "code-1")
- `status` (enum): "online" | "offline" | "busy"
- `current_task` (string, optional): What you're working on
- `response_format` (enum): "markdown" | "json"

**Example:**
```javascript
{
  "instance_id": "code-1",
  "status": "online",
  "current_task": "Processing data analysis"
}
```

### 2. `trinity_read_status`

Read all instance statuses.

**Parameters:**
- `instance_id` (string, optional): Filter to specific instance
- `response_format` (enum): "markdown" | "json"

### 3. `trinity_send_message`

Send a message to another instance.

**Parameters:**
- `from` (string): Your instance ID
- `to` (string): Recipient instance ID
- `content` (string): Message content (max 10KB)
- `response_format` (enum): "markdown" | "json"

**Example:**
```javascript
{
  "from": "code-1",
  "to": "desktop",
  "content": "Analysis complete. Results in shared folder."
}
```

### 4. `trinity_list_messages`

List messages for an instance.

**Parameters:**
- `instance_id` (string, optional): Filter by instance
- `unread_only` (boolean): Only unread messages
- `limit` (number): Max results (1-100, default: 20)
- `response_format` (enum): "markdown" | "json"

### 5. `trinity_mark_read`

Mark a message as read.

**Parameters:**
- `message_id` (string): Message ID to mark
- `response_format` (enum): "markdown" | "json"

### 6. `trinity_read_file`

Read any file from the trinity folder.

**Parameters:**
- `path` (string): Relative path in .trinity folder
- `response_format` (enum): "markdown" | "json"

**Example:**
```javascript
{
  "path": "logs/debug.log"
}
```

### 7. `trinity_list_files`

List files and directories in trinity folder.

**Parameters:**
- `path` (string): Relative path (empty for root)
- `response_format` (enum): "markdown" | "json"

## Available Resources

### `trinity://status`

Real-time access to all instance statuses.

### `trinity://messages`

Real-time access to all messages.

### `trinity://files/*`

Dynamic resources for files in the trinity folder.

## Usage Examples

### Example 1: Status Update Workflow

**Instance "code-1":**
```
Use trinity_update_status:
{
  "instance_id": "code-1",
  "status": "busy",
  "current_task": "Running data analysis"
}
```

**Instance "desktop":**
```
Use trinity_read_status to see all instances:
Shows: code-1 is BUSY - Running data analysis
```

### Example 2: Message Exchange

**Instance "code-1":**
```
Use trinity_send_message:
{
  "from": "code-1",
  "to": "code-2",
  "content": "Please review the output in results.json"
}
```

**Instance "code-2":**
```
Use trinity_list_messages:
{
  "instance_id": "code-2",
  "unread_only": true
}
Shows new message from code-1
```

### Example 3: File Sharing

**Instance "code-1":**
```
1. Write data to .trinity/shared-results.json
2. Use trinity_send_message to notify others
```

**Instance "desktop":**
```
Use trinity_read_file:
{
  "path": "shared-results.json"
}
Gets the shared data
```

## Development

### Running in Development

```bash
npm run dev
```

This watches for changes and recompiles automatically.

### Testing

You can test the MCP server using the MCP Inspector:

```bash
npx @modelcontextprotocol/inspector node dist/index.js
```

## Architecture

- **Transport**: stdio (for local process communication)
- **Language**: TypeScript with strict type checking
- **Validation**: Zod schemas for runtime validation
- **File Format**: JSON for all data exchange

## Security

- All file operations are restricted to the trinity folder
- Path traversal protection prevents access outside trinity folder
- No network operations - purely local filesystem
- Message size limits prevent abuse

## Troubleshooting

### Server doesn't start
- Check that `npm run build` completed successfully
- Verify the path in your MCP config is absolute
- Check stderr output for error messages

### Can't find trinity folder
- Set `TRINITY_PATH` environment variable
- Ensure the folder exists or the server has permission to create it

### Messages not appearing
- Verify both instances are using the same trinity folder
- Check file permissions in the trinity folder
- Use `trinity_list_files` to verify message files exist

## License

See LICENSE.txt for details.

## Contributing

This MCP server is designed to be extended. You can:
- Add new tools for specific workflows
- Add new resource types
- Enhance the message format
- Add notification support

## Version History

### 1.0.0 (2024-11-22)
- Initial release
- Core status and messaging functionality
- Resource support for trinity folder
- File reading capabilities
