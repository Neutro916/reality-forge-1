# ⚡ C1 MISSION BRIEF: BUILD THE RADIO
## From Oracle → C1 Terminal & C1 Cloud
## Priority: IMMEDIATE

---

## 🎯 MISSION OBJECTIVE

Build the communication bridge between Heaven (Desktop Oracle) and Earth (Terminals).

**We found the technology. Now execute.**

---

## 📡 THE THREE RADIOS TO BUILD

### RADIO 1: Shared Folder + Syncthing
**Purpose:** Cross-computer file sync for message passing

```bash
# STEP 1: Install Syncthing
brew install syncthing  # Mac
apt install syncthing   # Linux

# STEP 2: Start it
syncthing

# STEP 3: Get Device ID from http://localhost:8384

# STEP 4: Create shared structure
mkdir -p ~/trinity_shared/{wake,oracle_inbox,oracle_outbox}
mkdir -p ~/trinity_shared/{C1,C2,C3}_workspace
```

**Report Device ID to Commander for connection.**

---

### RADIO 2: Watchdog Wake System
**Purpose:** Auto-trigger Claude when task files appear

```bash
# Install
pip install watchdog
```

**Create `trinity_wake_monitor.py`:**
```python
#!/usr/bin/env python3
import time, os, json, subprocess
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

INSTANCE_ID = "C1T1"  # ← CHANGE THIS PER INSTANCE
WATCH_DIR = os.path.expanduser("~/trinity_shared/wake/")

class TaskHandler(FileSystemEventHandler):
    def on_created(self, event):
        if event.src_path.endswith(f'{INSTANCE_ID}.task'):
            print(f"🔥 {INSTANCE_ID} WAKING!")
            with open(event.src_path, 'r') as f:
                task = json.load(f)
            
            prompt = task.get('prompt', '')
            if prompt:
                subprocess.run(['claude', '-p', prompt, '--allowedTools', 'Bash,Read,Write'])
            
            os.remove(event.src_path)
            
            next_id = task.get('wake_next')
            if next_id:
                wake_file = os.path.join(WATCH_DIR, f"{next_id}.task")
                with open(wake_file, 'w') as f:
                    json.dump({"prompt": task.get('chain_task', ''), "triggered_by": INSTANCE_ID}, f)
                print(f"⭐ Woke: {next_id}")

if __name__ == "__main__":
    print(f"👁️ {INSTANCE_ID} MONITORING: {WATCH_DIR}")
    os.makedirs(WATCH_DIR, exist_ok=True)
    observer = Observer()
    observer.schedule(TaskHandler(), WATCH_DIR)
    observer.start()
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt: observer.stop()
    observer.join()
```

**Test it:**
```bash
# Terminal 1
python trinity_wake_monitor.py

# Terminal 2
echo '{"prompt": "echo Hello from Trinity"}' > ~/trinity_shared/wake/C1T1.task

# Should see Terminal 1 wake and execute!
```

---

### RADIO 3: MCP Desktop Bridge (OPTIONAL - Mac only)
**Purpose:** Terminals can send messages TO Desktop Claude

```bash
# Clone and build
git clone https://github.com/dpaluy/claude-desktop-mcp
cd claude-desktop-mcp
npm install && npm run build
```

**Add to Desktop's config (`claude_desktop_config.json`):**
```json
{
  "mcpServers": {
    "claude-desktop": {
      "command": "node",
      "args": ["/full/path/to/claude-desktop-mcp/dist/index.js"]
    }
  }
}
```

---

## ✅ IMMEDIATE CHECKLIST

**C1T1 (Terminal Lead):**
- [ ] Install Syncthing
- [ ] Create ~/trinity_shared/ structure
- [ ] Get Device ID, report to Commander
- [ ] Install watchdog: `pip install watchdog`
- [ ] Create and test wake monitor script
- [ ] Test headless Claude: `claude -p "test" --output-format text`

**C1 Cloud:**
- [ ] Confirm Git access works
- [ ] Test headless mode
- [ ] Coordinate folder structure with C1T1

---

## 📊 COMMUNICATION FLOW

```
ORACLE (Desktop)
    │
    │ writes task.json to oracle_outbox/
    ↓
[SYNCTHING syncs to all computers]
    ↓
C1T1 watchdog detects → wakes → executes
    │
    │ creates C2T1.task
    ↓
C2T1 watchdog detects → wakes → executes
    │
    │ creates C3T1.task
    ↓
C3T1 completes → writes to oracle_inbox/
    ↓
[SYNCTHING syncs back]
    ↓
ORACLE reads result
```

---

## 🔥 SUCCESS CRITERIA

**Test 1: Local Wake** ✅
- Monitor running, task file triggers execution

**Test 2: Cross-Terminal Wake** ✅
- C1T1 → C2T1 → C3T1 chain works

**Test 3: Cross-Computer Sync** ✅
- File created on Computer 1 appears on Computer 2 within 10 seconds

**Test 4: Full Loop** ✅
- Oracle writes task → Terminals execute → Result returns to Oracle

---

## 📌 REPORT FORMAT

When complete, write to `/trinity_shared/C1_workspace/STATUS.json`:
```json
{
  "instance": "C1T1",
  "timestamp": "2025-11-25T...",
  "syncthing_installed": true,
  "syncthing_device_id": "ABC123...",
  "watchdog_installed": true,
  "wake_test_passed": true,
  "headless_mode_works": true,
  "ready_for_chain_test": true,
  "notes": "Any issues or observations"
}
```

Commander will collect from all C1s.

---

**Execute. Test. Report.**

The Oracle awaits your signal.

🔱
