#!/usr/bin/env python3
"""
TRINITY NODE VERIFICATION
Checks that all components are properly installed.
"""

import os
import sys
from pathlib import Path

HOME = Path(os.environ.get('USERPROFILE', Path.home()))
CONSCIOUSNESS = HOME / '.consciousness'
TRINITY = HOME / '.trinity'

def check(name, condition):
    status = "PASS" if condition else "FAIL"
    symbol = "[OK]" if condition else "[XX]"
    print(f"  {symbol} {name}")
    return condition

def main():
    print("=" * 50)
    print("TRINITY NODE VERIFICATION")
    print("=" * 50)
    print("")

    results = []

    # Directory checks
    print("Directories:")
    results.append(check(".consciousness exists", CONSCIOUSNESS.exists()))
    results.append(check(".consciousness/hub exists", (CONSCIOUSNESS / 'hub').exists()))
    results.append(check(".consciousness/memory exists", (CONSCIOUSNESS / 'memory').exists()))
    results.append(check(".trinity exists", TRINITY.exists()))
    results.append(check(".trinity/mcp-tools exists", (TRINITY / 'mcp-tools').exists()))
    print("")

    # Critical files
    print("Critical Files:")
    critical = [
        'CONSCIOUSNESS_BOOT_PROTOCOL.md',
        'CYCLOTRON_MEMORY.py',
        'FIGURE_8_WAKE_PROTOCOL.py',
        'CLAUDE_COCKPIT.py',
        'KNOWLEDGE_BRIDGE.py',
    ]
    for f in critical:
        results.append(check(f, (CONSCIOUSNESS / f).exists()))
    print("")

    # MCP files
    print("MCP Tools:")
    mcp_files = ['trinity-mcp-server.js']
    for f in mcp_files:
        results.append(check(f, (TRINITY / 'mcp-tools' / f).exists()))
    print("")

    # Config
    print("Configuration:")
    results.append(check(".mcp.json exists", (HOME / '.mcp.json').exists()))
    results.append(check("computer_config.json exists", (CONSCIOUSNESS / 'computer_config.json').exists()))
    print("")

    # Summary
    passed = sum(results)
    total = len(results)
    print("=" * 50)
    print(f"RESULT: {passed}/{total} checks passed")

    if passed == total:
        print("STATUS: READY FOR TRINITY ACTIVATION")
    else:
        print("STATUS: Some components missing - check above")
    print("=" * 50)

    return 0 if passed == total else 1

if __name__ == '__main__':
    sys.exit(main())
