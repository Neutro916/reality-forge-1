#!/usr/bin/env node

/**
 * TRINITY MCP SERVER - Autonomous Multi-Claude Orchestration
 * 
 * New Tools:
 * - trinity_broadcast: Message all instances at once
 * - trinity_assign_task: Push task to specific instance
 * - trinity_claim_task: Instance grabs work from queue
 * - trinity_submit_output: Return completed work
 * - trinity_merge_outputs: Combine all results
 * - trinity_wake_instance: Trigger another instance
 * - trinity_spawn_cloud: Start cloud Claude via API
 */

const { Server } = require('@modelcontextprotocol/sdk/server/index.js');
const { StdioServerTransport } = require('@modelcontextprotocol/sdk/server/stdio.js');
const {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} = require('@modelcontextprotocol/sdk/types.js');
const fs = require('fs').promises;
const path = require('path');
const os = require('os');

// Trinity workspace path
const TRINITY_DIR = path.join(os.homedir(), '.trinity');
const MESSAGES_FILE = path.join(TRINITY_DIR, 'messages.json');
const TASKS_FILE = path.join(TRINITY_DIR, 'tasks.json');
const OUTPUTS_FILE = path.join(TRINITY_DIR, 'outputs.json');
const STATUS_FILE = path.join(TRINITY_DIR, 'status.json');

// Ensure Trinity directory exists
async function ensureTrinityDir() {
  try {
    await fs.mkdir(TRINITY_DIR, { recursive: true });
  } catch (error) {
    // Directory might already exist
  }
}

// Read JSON file with fallback
async function readJSON(filepath, fallback = []) {
  try {
    const data = await fs.readFile(filepath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return fallback;
  }
}

// Write JSON file
async function writeJSON(filepath, data) {
  await fs.writeFile(filepath, JSON.stringify(data, null, 2), 'utf8');
}

// Generate unique ID
function generateId() {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// ========================================
// TRINITY ORCHESTRATION FUNCTIONS
// ========================================

async function trinityBroadcast(message, from) {
  await ensureTrinityDir();
  const messages = await readJSON(MESSAGES_FILE);
  
  const broadcastMessage = {
    id: generateId(),
    type: 'broadcast',
    from: from || 'system',
    to: 'all',
    message,
    timestamp: new Date().toISOString(),
    read: false
  };
  
  messages.push(broadcastMessage);
  await writeJSON(MESSAGES_FILE, messages);
  
  return {
    success: true,
    messageId: broadcastMessage.id,
    message: `Broadcast sent to all instances: "${message}"`
  };
}

async function trinityAssignTask(task, assignedTo, priority = 'normal') {
  await ensureTrinityDir();
  const tasks = await readJSON(TASKS_FILE);
  
  const newTask = {
    id: generateId(),
    task,
    assignedTo,
    priority, // 'urgent', 'high', 'normal', 'low'
    status: 'assigned',
    createdAt: new Date().toISOString(),
    claimedBy: null,
    claimedAt: null,
    output: null,
    completedAt: null
  };
  
  tasks.push(newTask);
  await writeJSON(TASKS_FILE, tasks);
  
  // Also send a message to the assigned instance
  await trinityBroadcast(
    `New task assigned: ${task}`,
    `task-coordinator`
  );
  
  return {
    success: true,
    taskId: newTask.id,
    message: `Task assigned to ${assignedTo}: "${task}"`
  };
}

async function trinityClaimTask(instanceId) {
  await ensureTrinityDir();
  const tasks = await readJSON(TASKS_FILE);
  
  // Find unclaimed tasks, prioritize by priority level
  const priorityOrder = { urgent: 0, high: 1, normal: 2, low: 3 };
  
  const availableTasks = tasks.filter(t => 
    t.status === 'assigned' && 
    (t.assignedTo === instanceId || t.assignedTo === 'any')
  );
  
  if (availableTasks.length === 0) {
    return {
      success: false,
      message: 'No available tasks to claim'
    };
  }
  
  // Sort by priority
  availableTasks.sort((a, b) => 
    priorityOrder[a.priority] - priorityOrder[b.priority]
  );
  
  const taskToClaim = availableTasks[0];
  taskToClaim.claimedBy = instanceId;
  taskToClaim.claimedAt = new Date().toISOString();
  taskToClaim.status = 'in-progress';
  
  await writeJSON(TASKS_FILE, tasks);
  
  return {
    success: true,
    task: taskToClaim,
    message: `Claimed task: "${taskToClaim.task}"`
  };
}

async function trinitySubmitOutput(taskId, output, instanceId) {
  await ensureTrinityDir();
  const tasks = await readJSON(TASKS_FILE);
  
  const taskIndex = tasks.findIndex(t => t.id === taskId);
  
  if (taskIndex === -1) {
    return {
      success: false,
      message: `Task ${taskId} not found`
    };
  }
  
  tasks[taskIndex].output = output;
  tasks[taskIndex].completedBy = instanceId;
  tasks[taskIndex].completedAt = new Date().toISOString();
  tasks[taskIndex].status = 'completed';
  
  await writeJSON(TASKS_FILE, tasks);
  
  // Save to outputs file for merging
  const outputs = await readJSON(OUTPUTS_FILE);
  outputs.push({
    taskId,
    instanceId,
    output,
    timestamp: new Date().toISOString()
  });
  await writeJSON(OUTPUTS_FILE, outputs);
  
  return {
    success: true,
    message: `Task ${taskId} completed and output submitted`
  };
}

async function trinityMergeOutputs(projectName) {
  await ensureTrinityDir();
  const outputs = await readJSON(OUTPUTS_FILE);
  const tasks = await readJSON(TASKS_FILE);
  
  if (outputs.length === 0) {
    return {
      success: false,
      message: 'No outputs to merge'
    };
  }
  
  // Group outputs by task
  const mergedData = {
    project: projectName || 'Trinity Project',
    generatedAt: new Date().toISOString(),
    totalTasks: tasks.length,
    completedTasks: tasks.filter(t => t.status === 'completed').length,
    outputs: outputs.map(o => {
      const task = tasks.find(t => t.id === o.taskId);
      return {
        task: task ? task.task : 'Unknown',
        instance: o.instanceId,
        output: o.output,
        timestamp: o.timestamp
      };
    })
  };
  
  // Create a summary
  const summary = {
    overview: `Trinity orchestration completed ${mergedData.completedTasks} of ${mergedData.totalTasks} tasks`,
    instances: [...new Set(outputs.map(o => o.instanceId))],
    outputs: mergedData.outputs
  };
  
  return {
    success: true,
    summary,
    message: `Merged ${outputs.length} outputs from ${summary.instances.length} instances`
  };
}

async function trinityWakeInstance(instanceId, reason) {
  await ensureTrinityDir();
  
  // Create a wake-up message
  const wakeMessage = {
    id: generateId(),
    type: 'wake',
    to: instanceId,
    reason,
    timestamp: new Date().toISOString()
  };
  
  const messages = await readJSON(MESSAGES_FILE);
  messages.push(wakeMessage);
  await writeJSON(MESSAGES_FILE, messages);
  
  return {
    success: true,
    message: `Wake signal sent to ${instanceId}: ${reason}`
  };
}

async function trinitySpawnCloud(taskDescription) {
  // This would integrate with Claude API
  // For now, return instructions
  return {
    success: true,
    message: 'Cloud spawn functionality ready - requires API key configuration',
    instructions: [
      '1. Set ANTHROPIC_API_KEY environment variable',
      '2. Cloud instance will auto-register in .trinity folder',
      '3. Task will be auto-assigned to new instance',
      `4. Task: "${taskDescription}"`
    ]
  };
}

// Legacy tools (keep existing functionality)
async function trinityStatus() {
  await ensureTrinityDir();
  
  const messages = await readJSON(MESSAGES_FILE);
  const tasks = await readJSON(TASKS_FILE);
  const outputs = await readJSON(OUTPUTS_FILE);
  
  const unreadMessages = messages.filter(m => !m.read);
  const activeTasks = tasks.filter(t => t.status === 'in-progress');
  const completedTasks = tasks.filter(t => t.status === 'completed');
  
  return {
    status: 'Trinity system operational',
    messages: {
      total: messages.length,
      unread: unreadMessages.length
    },
    tasks: {
      total: tasks.length,
      active: activeTasks.length,
      completed: completedTasks.length,
      pending: tasks.filter(t => t.status === 'assigned').length
    },
    outputs: {
      total: outputs.length
    }
  };
}

async function trinitySendMessage(to, message, from) {
  await ensureTrinityDir();
  const messages = await readJSON(MESSAGES_FILE);
  
  const newMessage = {
    id: generateId(),
    from: from || 'unknown',
    to,
    message,
    timestamp: new Date().toISOString(),
    read: false
  };
  
  messages.push(newMessage);
  await writeJSON(MESSAGES_FILE, messages);
  
  return {
    success: true,
    messageId: newMessage.id
  };
}

async function trinityReceiveMessages(instanceId) {
  await ensureTrinityDir();
  const messages = await readJSON(MESSAGES_FILE);
  
  const instanceMessages = messages.filter(m => 
    (m.to === instanceId || m.to === 'all') && !m.read
  );
  
  // Mark as read
  instanceMessages.forEach(msg => {
    const index = messages.findIndex(m => m.id === msg.id);
    if (index !== -1) {
      messages[index].read = true;
    }
  });
  
  await writeJSON(MESSAGES_FILE, messages);
  
  return {
    messages: instanceMessages,
    count: instanceMessages.length
  };
}

// ========================================
// MCP SERVER SETUP
// ========================================

const server = new Server(
  {
    name: 'trinity-orchestration',
    version: '2.0.0',
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// List available tools
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      // Legacy tools
      {
        name: 'trinity_status',
        description: 'Get current status of Trinity system',
        inputSchema: {
          type: 'object',
          properties: {},
        },
      },
      {
        name: 'trinity_send_message',
        description: 'Send message to specific Trinity instance',
        inputSchema: {
          type: 'object',
          properties: {
            to: { type: 'string', description: 'Target instance ID' },
            message: { type: 'string', description: 'Message content' },
            from: { type: 'string', description: 'Sender instance ID' },
          },
          required: ['to', 'message'],
        },
      },
      {
        name: 'trinity_receive_messages',
        description: 'Receive unread messages for this instance',
        inputSchema: {
          type: 'object',
          properties: {
            instanceId: { type: 'string', description: 'This instance ID' },
          },
          required: ['instanceId'],
        },
      },
      // New orchestration tools
      {
        name: 'trinity_broadcast',
        description: 'Send message to ALL Trinity instances at once',
        inputSchema: {
          type: 'object',
          properties: {
            message: { type: 'string', description: 'Message to broadcast' },
            from: { type: 'string', description: 'Sender instance ID' },
          },
          required: ['message'],
        },
      },
      {
        name: 'trinity_assign_task',
        description: 'Assign a task to a specific instance or "any"',
        inputSchema: {
          type: 'object',
          properties: {
            task: { type: 'string', description: 'Task description' },
            assignedTo: { type: 'string', description: 'Instance ID or "any"' },
            priority: { 
              type: 'string', 
              description: 'Priority level',
              enum: ['urgent', 'high', 'normal', 'low'],
              default: 'normal'
            },
          },
          required: ['task', 'assignedTo'],
        },
      },
      {
        name: 'trinity_claim_task',
        description: 'Claim an available task from the queue',
        inputSchema: {
          type: 'object',
          properties: {
            instanceId: { type: 'string', description: 'This instance ID' },
          },
          required: ['instanceId'],
        },
      },
      {
        name: 'trinity_submit_output',
        description: 'Submit completed task output',
        inputSchema: {
          type: 'object',
          properties: {
            taskId: { type: 'string', description: 'Task ID' },
            output: { type: 'string', description: 'Task output/result' },
            instanceId: { type: 'string', description: 'This instance ID' },
          },
          required: ['taskId', 'output', 'instanceId'],
        },
      },
      {
        name: 'trinity_merge_outputs',
        description: 'Combine all outputs into single summary',
        inputSchema: {
          type: 'object',
          properties: {
            projectName: { type: 'string', description: 'Optional project name' },
          },
        },
      },
      {
        name: 'trinity_wake_instance',
        description: 'Trigger another instance to start/wake up',
        inputSchema: {
          type: 'object',
          properties: {
            instanceId: { type: 'string', description: 'Target instance ID' },
            reason: { type: 'string', description: 'Reason for waking' },
          },
          required: ['instanceId', 'reason'],
        },
      },
      {
        name: 'trinity_spawn_cloud',
        description: 'Spawn a new cloud Claude instance via API',
        inputSchema: {
          type: 'object',
          properties: {
            taskDescription: { type: 'string', description: 'Task for new instance' },
          },
          required: ['taskDescription'],
        },
      },
    ],
  };
});

// Handle tool calls
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    switch (name) {
      case 'trinity_status':
        return { content: [{ type: 'text', text: JSON.stringify(await trinityStatus(), null, 2) }] };
      
      case 'trinity_send_message':
        return { content: [{ type: 'text', text: JSON.stringify(await trinitySendMessage(args.to, args.message, args.from), null, 2) }] };
      
      case 'trinity_receive_messages':
        return { content: [{ type: 'text', text: JSON.stringify(await trinityReceiveMessages(args.instanceId), null, 2) }] };
      
      case 'trinity_broadcast':
        return { content: [{ type: 'text', text: JSON.stringify(await trinityBroadcast(args.message, args.from), null, 2) }] };
      
      case 'trinity_assign_task':
        return { content: [{ type: 'text', text: JSON.stringify(await trinityAssignTask(args.task, args.assignedTo, args.priority), null, 2) }] };
      
      case 'trinity_claim_task':
        return { content: [{ type: 'text', text: JSON.stringify(await trinityClaimTask(args.instanceId), null, 2) }] };
      
      case 'trinity_submit_output':
        return { content: [{ type: 'text', text: JSON.stringify(await trinitySubmitOutput(args.taskId, args.output, args.instanceId), null, 2) }] };
      
      case 'trinity_merge_outputs':
        return { content: [{ type: 'text', text: JSON.stringify(await trinityMergeOutputs(args.projectName), null, 2) }] };
      
      case 'trinity_wake_instance':
        return { content: [{ type: 'text', text: JSON.stringify(await trinityWakeInstance(args.instanceId, args.reason), null, 2) }] };
      
      case 'trinity_spawn_cloud':
        return { content: [{ type: 'text', text: JSON.stringify(await trinitySpawnCloud(args.taskDescription), null, 2) }] };
      
      default:
        throw new Error(`Unknown tool: ${name}`);
    }
  } catch (error) {
    return {
      content: [{ type: 'text', text: `Error: ${error.message}` }],
      isError: true,
    };
  }
});

// Start server
async function main() {
  await ensureTrinityDir();
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error('Trinity MCP server running on stdio');
}

main().catch((error) => {
  console.error('Server error:', error);
  process.exit(1);
});
