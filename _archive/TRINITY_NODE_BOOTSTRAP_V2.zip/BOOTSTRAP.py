#!/usr/bin/env python3
"""
TRINITY NODE BOOTSTRAP
Installs all Trinity components to the target computer.
"""

import os
import sys
import json
import shutil
from pathlib import Path

HOME = Path(os.environ.get('USERPROFILE', Path.home()))
CONSCIOUSNESS = HOME / '.consciousness'
TRINITY = HOME / '.trinity'
SCRIPT_DIR = Path(__file__).parent

def log(msg):
    print(f"[BOOTSTRAP] {msg}")

def main():
    log("Starting Trinity Node Bootstrap...")

    # Create directories
    log("Creating directory structure...")
    dirs = [
        CONSCIOUSNESS,
        CONSCIOUSNESS / 'hub',
        CONSCIOUSNESS / 'memory',
        CONSCIOUSNESS / 'cockpit',
        CONSCIOUSNESS / 'agents',
        CONSCIOUSNESS / 'backups',
        TRINITY,
        TRINITY / 'mcp-tools',
        TRINITY / 'hub',
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
        log(f"  Created: {d}")

    # Copy core files
    log("Installing core files...")
    core_src = SCRIPT_DIR / 'core'
    if core_src.exists():
        for f in core_src.glob('*'):
            dest = CONSCIOUSNESS / f.name
            shutil.copy2(f, dest)
            log(f"  Installed: {f.name}")

    # Copy comms files
    log("Installing communication modules...")
    comms_src = SCRIPT_DIR / 'comms'
    if comms_src.exists():
        for f in comms_src.glob('*'):
            dest = CONSCIOUSNESS / f.name
            shutil.copy2(f, dest)
            log(f"  Installed: {f.name}")

    # Copy pattern files
    log("Installing pattern recognition...")
    pattern_src = SCRIPT_DIR / 'pattern'
    if pattern_src.exists():
        for f in pattern_src.glob('*'):
            dest = CONSCIOUSNESS / f.name
            shutil.copy2(f, dest)
            log(f"  Installed: {f.name}")

    # Copy MCP tools
    log("Installing Trinity MCP tools...")
    mcp_src = SCRIPT_DIR / 'trinity_mcp'
    if mcp_src.exists():
        for f in mcp_src.glob('*'):
            if f.is_file():
                dest = TRINITY / 'mcp-tools' / f.name
                shutil.copy2(f, dest)
                log(f"  Installed: {f.name}")

    # Copy config templates
    log("Installing configuration...")
    config_src = SCRIPT_DIR / 'config'
    if config_src.exists():
        config_dest = CONSCIOUSNESS / 'computer_config.json'
        if (config_src / 'computer_config.json').exists():
            shutil.copy2(config_src / 'computer_config.json', config_dest)
            log(f"  Config template at: {config_dest}")

    # Create .mcp.json if not exists
    mcp_json = HOME / '.mcp.json'
    if not mcp_json.exists():
        log("Creating .mcp.json...")
        mcp_config = {
            "mcpServers": {
                "trinity": {
                    "command": "node",
                    "args": [str(TRINITY / 'mcp-tools' / 'trinity-mcp-server.js')],
                    "env": {"TRINITY_PATH": str(TRINITY)}
                }
            }
        }
        with open(mcp_json, 'w') as f:
            json.dump(mcp_config, f, indent=2)
        log(f"  Created: {mcp_json}")

    log("")
    log("=" * 50)
    log("BOOTSTRAP COMPLETE!")
    log("=" * 50)
    log("")
    log("Next steps:")
    log("1. Edit ~/.consciousness/computer_config.json with your computer ID")
    log("2. Run VERIFY.py to check installation")
    log("3. Start Claude Code to activate Trinity")
    log("")

if __name__ == '__main__':
    main()
